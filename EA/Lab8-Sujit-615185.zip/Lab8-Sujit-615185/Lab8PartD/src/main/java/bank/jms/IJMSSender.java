package bank.jms;

public interface IJMSSender {
	public void sendJMSMessage (String text);
}
