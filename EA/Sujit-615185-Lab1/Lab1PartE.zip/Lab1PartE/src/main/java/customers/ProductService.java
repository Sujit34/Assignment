package customers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService implements IProductService{
    @Autowired
    private IProductDAO productDAO;
    @Autowired
    private IEmailSender emailSender;

    public void addProduct(String name, int price) {
        Product product = new Product(name, price);
        productDAO.save(product);
        emailSender.sendEmail("abc@gmail.com",  name + " is added.");
    }
}
