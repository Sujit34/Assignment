package customers;

public interface IProductDAO {
    void save(Product product);
}
