package customers;

public interface IProductService {
    void addProduct(String name, int price);
}
