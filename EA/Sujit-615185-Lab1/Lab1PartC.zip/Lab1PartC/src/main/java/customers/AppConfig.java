package customers;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean
    public CustomerService customerService(){
        CustomerService customerService = new CustomerService();
        customerService.setEmailSender(emailService());
        customerService.setCustomerDAO(customerDAO());
        return customerService;
    }
    @Bean
    public EmailSender emailService(){
        EmailSender emailSender = new EmailSender();
        emailSender.setLogger(logger());
        return emailSender;
    }
    @Bean
    public CustomerDAO customerDAO(){
        CustomerDAO customerDAO = new CustomerDAO();
        customerDAO.setLogger(logger());
        return customerDAO;
    }

    @Bean
    public Logger logger(){
        return new Logger();
    }
}
